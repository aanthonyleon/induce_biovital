<?php 
	define('SITE_KEY',"6Lf0m9UbAAAAAGSV206tkmlFZZq56LkIbfIebc2K"); 
	define('SECRET_KEY',"6Lf0m9UbAAAAAFJsUfeWVmv9HQiXqmS2RwtQk3sR");
?>